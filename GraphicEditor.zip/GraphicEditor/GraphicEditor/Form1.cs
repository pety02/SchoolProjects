﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO;

namespace GraphicEditor
{
    public partial class Form1 : Form
    {
        Graphics g;
        Bitmap bmp;
        Color paintColor = Color.Black;
        Color backColor;
        bool draw = false;
        bool chooseColor = false;
        Item currentTool;
        int x, y, lx, ly;

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            currentTool = Item.Rectangle;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            currentTool = Item.Ellipse;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            currentTool = Item.Line;
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            currentTool = Item.Pencil;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            currentTool = Item.Brush;
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            currentTool = Item.Ereaser;
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            ColorDialog c = new ColorDialog();
            if (c.ShowDialog() == DialogResult.OK)
            {
                paintColor = c.Color;
                toolStripButton7.BackColor = c.Color;
            }
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            ColorDialog bc = new ColorDialog();
            if (bc.ShowDialog() == DialogResult.OK)
            {
                backColor = bc.Color;
                toolStripButton8.BackColor = bc.Color;
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            size = (int)numericUpDown1.Value;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Cross;
            if (e.Button == MouseButtons.Left)
            {
                draw = true;
            }
            x = e.X;
            y = e.Y;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Default;
            draw = false;
            lx = e.X;
            ly = e.Y;

            switch (currentTool)
            {
                case Item.Rectangle:
                    if (checkBox1.Checked)
                    {
                        g.DrawRectangle(new Pen(paintColor, size), x, y, lx-x, ly-y);
                    }
                    if (checkBox2.Checked)
                    {
                        g.FillRectangle(new SolidBrush(backColor), x, y, lx-x, ly-y);
                    }
                    break;
                case Item.Ellipse:
                    if (checkBox1.Checked)
                    {
                        g.DrawEllipse(new Pen(paintColor, size), x, y, lx - x, ly - y);
                    }
                    if (checkBox2.Checked)
                    {
                        g.FillEllipse(new SolidBrush(backColor), x, y, lx - x, ly - y);
                    }
                    break;
                case Item.Line:
                    g.DrawLine(new Pen(paintColor, size), new Point(x, y), new Point(lx - x, ly - y));
                    break;
                default:
                    break;
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (!draw)
            {
                return;
            }

            if (draw)
            {
                switch (currentTool)
                {
                    case Item.Pencil:
                        Pen pen = new Pen(paintColor, size);
                        pen.StartCap = pen.EndCap = LineCap.Round;
                        g.DrawLine(pen, new Point(x, y), e.Location);
                        x = e.X;
                        y = e.Y;
                        break;
                    case Item.Brush:
                        //HatchBrush hb = new HatchBrush(HatchStyle.ZigZag, paintColor, backColor);
                        //g.FillEllipse(hb, e.X, e.Y, size, size);

                        //LinearGradientBrush lgb = new LinearGradientBrush(new Rectangle(e.X, e.Y, size, size), paintColor, backColor, LinearGradientMode.Vertical);
                        //g.FillRectangle(lgb, e.X, e.Y, size, size);

                        TextureBrush tb = new TextureBrush(GraphicEditor.Properties.Resources.b);
                        g.FillRectangle(tb, e.X, e.Y, size, size);
                        break;
                    case Item.Ereaser:
                        g.FillEllipse(new SolidBrush(pictureBox1.BackColor), e.X, e.Y, size, size);
                        break;
                    default:
                        break;
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                int width = Convert.ToInt32(pictureBox1.Width);
                int height = Convert.ToInt32(pictureBox1.Height);
                Bitmap bmp = new Bitmap(width, height);
                pictureBox1.DrawToBitmap(bmp, new Rectangle(0, 0, width, height));
                bmp.Save(dialog.FileName, ImageFormat.Jpeg);
            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form newForm = new Form();
            newForm.Text = "Help";
            
            RichTextBox txt = new RichTextBox();
            txt.Width = newForm.Width;
            txt.Text = "School project" + Environment.NewLine + " Graphical Editor" + Environment.NewLine + " Author: Petya Licheva, 12g";
            txt.ReadOnly = true;
            txt.Visible = true;

            newForm.Controls.Add(txt);

            newForm.ShowDialog();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Refresh();
            pictureBox1.Image = null;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openD = new OpenFileDialog();
            openD.Filter = "png files|*.png|jpeg files|*.jpg|bitmaps|*.bmp";
            if (openD.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = (Image)Image.FromFile(openD.FileName).Clone();
            }
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            if (chooseColor)
            {
                Bitmap bmp = (Bitmap)pictureBox2.Image.Clone();
                paintColor = bmp.GetPixel(e.X, e.Y);
                pictureBox3.BackColor = paintColor;
                label6.Text = paintColor.R.ToString();
                label7.Text = paintColor.G.ToString();
                label8.Text = paintColor.B.ToString();
                trackBar1.Value = paintColor.R;
                trackBar2.Value = paintColor.G;
                trackBar3.Value = paintColor.B;
            }
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            chooseColor = true;
        }

        private void pictureBox2_MouseUp(object sender, MouseEventArgs e)
        {
            chooseColor = false;
        }

        int size = 1;
        public Form1()
        {
            InitializeComponent();
            pictureBox1.ClientSize = new Size(1200, 800);
            g = pictureBox1.CreateGraphics();
            g.SmoothingMode = SmoothingMode.AntiAlias;
        }

        public enum Item
        {
            Rectangle, Ellipse, Line, Pencil, Brush, Ereaser
        }
    }
}
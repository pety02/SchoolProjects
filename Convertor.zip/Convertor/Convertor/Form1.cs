﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Convertor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            numTxt.TabIndex = 0;
            resetForm();
        }

        private void fromCm_CheckedChanged_1(object sender, EventArgs e)
        {
            fromMeasureLbl.Text = "cm";
            convertToGroupBox.Enabled = true;
            toCm.Enabled = false;
            toCm.Checked = false;
            toM.Enabled = true;
            toKm.Enabled = true;
        }

        private void fromM_CheckedChanged(object sender, EventArgs e)
        {
            fromMeasureLbl.Text = "m";
            convertToGroupBox.Enabled = true;
            toM.Enabled = false;
            toM.Checked = false;
            toCm.Enabled = true;
            toKm.Enabled = true;
        }

        private void fromKm_CheckedChanged(object sender, EventArgs e)
        {
            fromMeasureLbl.Text = "km";
            convertToGroupBox.Enabled = true;
            toKm.Enabled = false;
            toKm.Checked = false;
            toCm.Enabled = true;
            toM.Enabled = true;
        }

        private void toCm_CheckedChanged(object sender, EventArgs e)
        {
            toMeasureLbl.Text = "cm";
            convertBtn.Enabled = true;
            fromCm.Enabled = false;
            fromCm.Checked = false;
            fromM.Enabled = true;
            fromKm.Enabled = true;
        }

        private void toM_CheckedChanged(object sender, EventArgs e)
        {
            toMeasureLbl.Text = "m";
            convertBtn.Enabled = true;
            fromM.Enabled = false;
            fromM.Checked = false;
            fromCm.Enabled = true;
            fromKm.Enabled = true;
        }

        private void toKm_CheckedChanged(object sender, EventArgs e)
        {
            toMeasureLbl.Text = "km";
            convertBtn.Enabled = true;
            fromKm.Enabled = false;
            fromKm.Checked = false;
            fromCm.Enabled = true;
            fromM.Enabled = true;
        }

        private void convertBtn_Click(object sender, EventArgs e)
        {
            convert();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            resetForm();

            fromCm.Enabled = true;
            fromM.Enabled = true;
            fromKm.Enabled = true;
        }

        private void resetForm() {

            fromCm.Checked = false;
            fromM.Checked = false;
            fromKm.Checked = false;

            convertToGroupBox.Enabled = false;

            toCm.Checked = false;
            toM.Checked = false;
            toKm.Checked = false;

            convertBtn.Enabled = false;
            numTxt.Clear();
            
            fromMeasureLbl.Text = "";
            toMeasureLbl.Text = "";
            resLbl.Text = "";
        }

        private void convert()
        {

            if (numTxt.Text != null && numTxt.Text != "" && IsAllDigits(numTxt.Text))
            {

                if (fromCm.Checked)
                {

                    if (toM.Checked)
                    {
                        double m = Double.Parse(numTxt.Text) / 100;
                        double m2 = Math.Round(m, 4);
                        resLbl.Text = "" + m2;
                    }
                    else if (toKm.Checked)
                    {
                        double km = Double.Parse(numTxt.Text) / 100 / 1000;
                        double km2 = Math.Round(km, 4);
                        resLbl.Text = "" + km2;
                    } 
                }
                else if (fromM.Checked)
                {
                    
                    if (toCm.Checked)
                    {
                        double cm = Double.Parse(numTxt.Text) * 100;
                        double cm2 = Math.Round(cm, 4);
                        resLbl.Text = "" + cm2;
                    }
                     else if (toKm.Checked)
                    {
                        double km = Double.Parse(numTxt.Text) / 1000;
                        double km2 = Math.Round(km, 4);
                        resLbl.Text = "" + km2;
                    }
                }
                else if (fromKm.Checked)
                {

                    if (toCm.Checked)
                    {
                        double cm = Double.Parse(numTxt.Text) * 100000;
                        double cm2 = Math.Round(cm, 4);
                        resLbl.Text = "" + cm2;
                    }
                    else if (toM.Checked)
                    {
                        double m = Double.Parse(numTxt.Text) * 1000;
                        double m2 = Math.Round(m, 4);
                        resLbl.Text = "" + m2;
                    }
                }
            }
            else
            {
                MessageBox.Show("Please, enter a number!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        } 

        private bool IsAllDigits(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsDigit(c))
                    return false;
            }
            return true;
        }
    }
}
﻿
namespace Convertor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.convertFromGroupBox = new System.Windows.Forms.GroupBox();
            this.fromKm = new System.Windows.Forms.RadioButton();
            this.fromM = new System.Windows.Forms.RadioButton();
            this.fromCm = new System.Windows.Forms.RadioButton();
            this.convertToGroupBox = new System.Windows.Forms.GroupBox();
            this.toCm = new System.Windows.Forms.RadioButton();
            this.toM = new System.Windows.Forms.RadioButton();
            this.toKm = new System.Windows.Forms.RadioButton();
            this.convertBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.numTxt = new System.Windows.Forms.TextBox();
            this.fromMeasureLbl = new System.Windows.Forms.Label();
            this.resTitleLbl = new System.Windows.Forms.Label();
            this.resLbl = new System.Windows.Forms.Label();
            this.toMeasureLbl = new System.Windows.Forms.Label();
            this.convertFromGroupBox.SuspendLayout();
            this.convertToGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // convertFromGroupBox
            // 
            this.convertFromGroupBox.Controls.Add(this.fromKm);
            this.convertFromGroupBox.Controls.Add(this.fromM);
            this.convertFromGroupBox.Controls.Add(this.fromCm);
            this.convertFromGroupBox.Location = new System.Drawing.Point(26, 29);
            this.convertFromGroupBox.Name = "convertFromGroupBox";
            this.convertFromGroupBox.Size = new System.Drawing.Size(200, 100);
            this.convertFromGroupBox.TabIndex = 0;
            this.convertFromGroupBox.TabStop = false;
            this.convertFromGroupBox.Text = "Convert From:";
            // 
            // fromKm
            // 
            this.fromKm.AutoSize = true;
            this.fromKm.Location = new System.Drawing.Point(12, 70);
            this.fromKm.Name = "fromKm";
            this.fromKm.Size = new System.Drawing.Size(72, 17);
            this.fromKm.TabIndex = 6;
            this.fromKm.TabStop = true;
            this.fromKm.Text = "kilometres";
            this.fromKm.UseVisualStyleBackColor = true;
            this.fromKm.CheckedChanged += new System.EventHandler(this.fromKm_CheckedChanged);
            // 
            // fromM
            // 
            this.fromM.AutoSize = true;
            this.fromM.Location = new System.Drawing.Point(12, 47);
            this.fromM.Name = "fromM";
            this.fromM.Size = new System.Drawing.Size(56, 17);
            this.fromM.TabIndex = 5;
            this.fromM.TabStop = true;
            this.fromM.Text = "metres";
            this.fromM.UseVisualStyleBackColor = true;
            this.fromM.CheckedChanged += new System.EventHandler(this.fromM_CheckedChanged);
            // 
            // fromCm
            // 
            this.fromCm.AutoSize = true;
            this.fromCm.Location = new System.Drawing.Point(12, 25);
            this.fromCm.Name = "fromCm";
            this.fromCm.Size = new System.Drawing.Size(79, 17);
            this.fromCm.TabIndex = 4;
            this.fromCm.TabStop = true;
            this.fromCm.Text = "centimetres";
            this.fromCm.UseVisualStyleBackColor = true;
            this.fromCm.CheckedChanged += new System.EventHandler(this.fromCm_CheckedChanged_1);
            // 
            // convertToGroupBox
            // 
            this.convertToGroupBox.Controls.Add(this.toCm);
            this.convertToGroupBox.Controls.Add(this.toM);
            this.convertToGroupBox.Controls.Add(this.toKm);
            this.convertToGroupBox.Location = new System.Drawing.Point(26, 157);
            this.convertToGroupBox.Name = "convertToGroupBox";
            this.convertToGroupBox.Size = new System.Drawing.Size(200, 100);
            this.convertToGroupBox.TabIndex = 0;
            this.convertToGroupBox.TabStop = false;
            this.convertToGroupBox.Text = "Convert To:";
            // 
            // toCm
            // 
            this.toCm.AutoSize = true;
            this.toCm.Location = new System.Drawing.Point(12, 24);
            this.toCm.Name = "toCm";
            this.toCm.Size = new System.Drawing.Size(79, 17);
            this.toCm.TabIndex = 4;
            this.toCm.TabStop = true;
            this.toCm.Text = "centimetres";
            this.toCm.UseVisualStyleBackColor = true;
            this.toCm.CheckedChanged += new System.EventHandler(this.toCm_CheckedChanged);
            // 
            // toM
            // 
            this.toM.AutoSize = true;
            this.toM.Location = new System.Drawing.Point(12, 48);
            this.toM.Name = "toM";
            this.toM.Size = new System.Drawing.Size(56, 17);
            this.toM.TabIndex = 5;
            this.toM.TabStop = true;
            this.toM.Text = "metres";
            this.toM.UseVisualStyleBackColor = true;
            this.toM.CheckedChanged += new System.EventHandler(this.toM_CheckedChanged);
            // 
            // toKm
            // 
            this.toKm.AutoSize = true;
            this.toKm.Location = new System.Drawing.Point(12, 72);
            this.toKm.Name = "toKm";
            this.toKm.Size = new System.Drawing.Size(72, 17);
            this.toKm.TabIndex = 6;
            this.toKm.TabStop = true;
            this.toKm.Text = "kilometres";
            this.toKm.UseVisualStyleBackColor = true;
            this.toKm.CheckedChanged += new System.EventHandler(this.toKm_CheckedChanged);
            // 
            // convertBtn
            // 
            this.convertBtn.Location = new System.Drawing.Point(26, 274);
            this.convertBtn.Name = "convertBtn";
            this.convertBtn.Size = new System.Drawing.Size(75, 23);
            this.convertBtn.TabIndex = 1;
            this.convertBtn.Text = "Convert";
            this.convertBtn.UseVisualStyleBackColor = true;
            this.convertBtn.Click += new System.EventHandler(this.convertBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(151, 274);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 2;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // numTxt
            // 
            this.numTxt.Location = new System.Drawing.Point(258, 94);
            this.numTxt.Name = "numTxt";
            this.numTxt.Size = new System.Drawing.Size(152, 20);
            this.numTxt.TabIndex = 3;
            // 
            // fromMeasureLbl
            // 
            this.fromMeasureLbl.AutoSize = true;
            this.fromMeasureLbl.Location = new System.Drawing.Point(416, 101);
            this.fromMeasureLbl.Name = "fromMeasureLbl";
            this.fromMeasureLbl.Size = new System.Drawing.Size(35, 13);
            this.fromMeasureLbl.TabIndex = 4;
            this.fromMeasureLbl.Text = "label1";
            // 
            // resTitleLbl
            // 
            this.resTitleLbl.AutoSize = true;
            this.resTitleLbl.Location = new System.Drawing.Point(258, 175);
            this.resTitleLbl.Name = "resTitleLbl";
            this.resTitleLbl.Size = new System.Drawing.Size(40, 13);
            this.resTitleLbl.TabIndex = 5;
            this.resTitleLbl.Text = "Result:";
            // 
            // resLbl
            // 
            this.resLbl.AutoSize = true;
            this.resLbl.Location = new System.Drawing.Point(375, 175);
            this.resLbl.Name = "resLbl";
            this.resLbl.Size = new System.Drawing.Size(35, 13);
            this.resLbl.TabIndex = 6;
            this.resLbl.Text = "label3";
            // 
            // toMeasureLbl
            // 
            this.toMeasureLbl.AutoSize = true;
            this.toMeasureLbl.Location = new System.Drawing.Point(416, 175);
            this.toMeasureLbl.Name = "toMeasureLbl";
            this.toMeasureLbl.Size = new System.Drawing.Size(35, 13);
            this.toMeasureLbl.TabIndex = 7;
            this.toMeasureLbl.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 326);
            this.Controls.Add(this.toMeasureLbl);
            this.Controls.Add(this.resLbl);
            this.Controls.Add(this.resTitleLbl);
            this.Controls.Add(this.fromMeasureLbl);
            this.Controls.Add(this.numTxt);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.convertBtn);
            this.Controls.Add(this.convertToGroupBox);
            this.Controls.Add(this.convertFromGroupBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.convertFromGroupBox.ResumeLayout(false);
            this.convertFromGroupBox.PerformLayout();
            this.convertToGroupBox.ResumeLayout(false);
            this.convertToGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox convertFromGroupBox;
        private System.Windows.Forms.GroupBox convertToGroupBox;
        private System.Windows.Forms.RadioButton toCm;
        private System.Windows.Forms.RadioButton toM;
        private System.Windows.Forms.RadioButton toKm;
        private System.Windows.Forms.Button convertBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.TextBox numTxt;
        private System.Windows.Forms.Label fromMeasureLbl;
        private System.Windows.Forms.Label resTitleLbl;
        private System.Windows.Forms.Label resLbl;
        private System.Windows.Forms.Label toMeasureLbl;
        private System.Windows.Forms.RadioButton fromCm;
        private System.Windows.Forms.RadioButton fromKm;
        private System.Windows.Forms.RadioButton fromM;
    }
}


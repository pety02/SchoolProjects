﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentsForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            clearAllControlers();
        }

        private void colorButton_Click(object sender, EventArgs e)
        {

            openColorsDialog();
        }

        private void fontButton_Click(object sender, EventArgs e)
        {

            openFontsDialog();
        }

        private void addButton_Click(object sender, EventArgs e)
        {

            addNewStudent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {

            clearAllControlers();
        }

        private void openColorsDialog()
        {

            ColorDialog colorsWindow = new ColorDialog();

            if (colorsWindow.ShowDialog() == DialogResult.OK)
            {
                StudentsListView.ForeColor = colorsWindow.Color;
            }
        }

        private void openFontsDialog()
        {

            FontDialog fontsWindow = new FontDialog();

            if (fontsWindow.ShowDialog() == DialogResult.OK)
            {
                StudentsListView.Font = fontsWindow.Font;
            }
        }

        private bool isValidName(string name)
        {

            if (!string.IsNullOrWhiteSpace(name) && char.IsUpper(name[0]))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool isValiPIN(string pin)
        {

            if (!string.IsNullOrWhiteSpace(pin) && pin.All(char.IsDigit) && pin.Length == 10)
            {
                int year = dateTimePicker.Value.Year;
                int month = dateTimePicker.Value.Month;
                int day = dateTimePicker.Value.Day;

                string pinStartsWith1 = "";
                string pinStartsWith2 = "";

                if (year >= 1900)
                {

                    string yearToString = year.ToString();
                    string monthToString1 = month.ToString();
                    string monthToString2 = (month + 40).ToString();
                    string dayToString = day.ToString();

                    string y = "" + yearToString[2] + yearToString[3];
                    string m1 = "" + monthToString1;
                    string m2 = "" + monthToString2;
                    string d = "" + dayToString;

                    pinStartsWith1 = y + m1 + d;
                    pinStartsWith2 = y + m2 + d;

                    if (year >= 1900 && year < 2000 && pin.StartsWith(pinStartsWith1))
                    {
                        return true;
                    }
                    else if (year >= 2000 && pin.StartsWith(pinStartsWith2))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        private bool isChosenGender()
        {

            if (femaleRadioButton.Checked || maleRadioButton.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool isChosenSchool()
        {

            if (schoolComboBox.SelectedIndex != -1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool isChosenForeignLanguagesList()
        {

            if (englishCheckBox.Checked || deutschCheckBox.Checked || frenchCheckBox.Checked || russianCheckBox.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void addNewStudent()
        {
            string nm = nameTextBox.Text;
            string egn = pinTextBox.Text;


            if (isValidName(nm) && isValiPIN(egn) && isChosenGender() && isChosenSchool() && isChosenForeignLanguagesList())
            {

                string sch = schoolComboBox.SelectedItem.ToString();
                string bd = dateTimePicker.Value.ToLongDateString();

                string gen = "";
                List<String> langs = new List<string>();

                if (maleRadioButton.Checked)
                {
                    gen = maleRadioButton.Text;

                }
                else if (femaleRadioButton.Checked)
                {
                    gen = femaleRadioButton.Text;

                }


                foreach (CheckBox item in foreignLanguagesGruopBox.Controls)
                {

                    if (item.Checked)
                    {

                        langs.Add(item.Text);
                    }
                }


                string langsStr = "";


                if (langs != null && langs.Count != 0)
                {


                    foreach (string item in langs)
                    {
                        langsStr += item + ", ";
                    }
                }

                DialogResult operation = MessageBox.Show("Do you want to print this student?", "Operation Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (operation == DialogResult.Yes)
                {
                    printNewStudent(nm, egn, bd, gen, sch, langsStr);
                }

            }
            else
            {
                showMessage("Please check Student Data!", "Invalid Student Data!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void clearAllControlers()
        {

            nameTextBox.Clear();
            pinTextBox.Clear();
            maleRadioButton.Checked = false;
            femaleRadioButton.Checked = false;

            schoolComboBox.SelectedIndex = -1;
            englishCheckBox.Checked = false;
            deutschCheckBox.Checked = false;
            frenchCheckBox.Checked = false;
            russianCheckBox.Checked = false;

            StudentsListView.Items.Clear();
        }

        private void showMessage(string message, string title, MessageBoxButtons buttons, MessageBoxIcon icon)
        {

            MessageBox.Show(message, title, buttons, icon);
        }

        private void printNewStudent(string name, string pin, string birthDate, string gender, string school, string languages)
        {

            StudentsListView.Items.Add("Student was added on: " + DateTime.Today.ToLongDateString());
            StudentsListView.Items.Add(Environment.NewLine);
            StudentsListView.Items.Add("Name -> " + name);
            StudentsListView.Items.Add("Personal Identification Number -> " + pin);
            StudentsListView.Items.Add("BirthDate -> " + birthDate);
            StudentsListView.Items.Add("Gender -> " + gender);
            StudentsListView.Items.Add("School -> " + school);
            StudentsListView.Items.Add("Foreign Languages -> " + languages);
            StudentsListView.Items.Add(Environment.NewLine);
            StudentsListView.Items.Add("---------------------------------------------");
        }
    }
}
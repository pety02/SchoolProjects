﻿
namespace StudentsForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateOfBirthLabel = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.editorLabel = new System.Windows.Forms.Label();
            this.schoolInformationLabel = new System.Windows.Forms.Label();
            this.personalInformationLabel = new System.Windows.Forms.Label();
            this.schoolComboBox = new System.Windows.Forms.ComboBox();
            this.pinTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.genderGroupBox = new System.Windows.Forms.GroupBox();
            this.femaleRadioButton = new System.Windows.Forms.RadioButton();
            this.maleRadioButton = new System.Windows.Forms.RadioButton();
            this.colorButton = new System.Windows.Forms.Button();
            this.fontBution = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.foreignLanguagesGruopBox = new System.Windows.Forms.GroupBox();
            this.russianCheckBox = new System.Windows.Forms.CheckBox();
            this.frenchCheckBox = new System.Windows.Forms.CheckBox();
            this.deutschCheckBox = new System.Windows.Forms.CheckBox();
            this.englishCheckBox = new System.Windows.Forms.CheckBox();
            this.StudentsListView = new System.Windows.Forms.ListBox();
            this.schoolLabel = new System.Windows.Forms.Label();
            this.pinLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.genderGroupBox.SuspendLayout();
            this.foreignLanguagesGruopBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // dateOfBirthLabel
            // 
            this.dateOfBirthLabel.AutoSize = true;
            this.dateOfBirthLabel.Location = new System.Drawing.Point(13, 145);
            this.dateOfBirthLabel.Name = "dateOfBirthLabel";
            this.dateOfBirthLabel.Size = new System.Drawing.Size(68, 13);
            this.dateOfBirthLabel.TabIndex = 37;
            this.dateOfBirthLabel.Text = "Date of birth:";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(193, 139);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(121, 20);
            this.dateTimePicker.TabIndex = 36;
            // 
            // editorLabel
            // 
            this.editorLabel.AutoSize = true;
            this.editorLabel.Location = new System.Drawing.Point(440, 101);
            this.editorLabel.Name = "editorLabel";
            this.editorLabel.Size = new System.Drawing.Size(37, 13);
            this.editorLabel.TabIndex = 35;
            this.editorLabel.Text = "Editor:";
            // 
            // schoolInformationLabel
            // 
            this.schoolInformationLabel.AutoSize = true;
            this.schoolInformationLabel.Location = new System.Drawing.Point(12, 273);
            this.schoolInformationLabel.Name = "schoolInformationLabel";
            this.schoolInformationLabel.Size = new System.Drawing.Size(98, 13);
            this.schoolInformationLabel.TabIndex = 34;
            this.schoolInformationLabel.Text = "School Information:";
            // 
            // personalInformationLabel
            // 
            this.personalInformationLabel.AutoSize = true;
            this.personalInformationLabel.Location = new System.Drawing.Point(12, 21);
            this.personalInformationLabel.Name = "personalInformationLabel";
            this.personalInformationLabel.Size = new System.Drawing.Size(105, 13);
            this.personalInformationLabel.TabIndex = 33;
            this.personalInformationLabel.Text = "Personal information:";
            // 
            // schoolComboBox
            // 
            this.schoolComboBox.FormattingEnabled = true;
            this.schoolComboBox.Items.AddRange(new object[] {
            "Mathemathical High School \'Geo Milev\' - Pleven, Bulgaria",
            "High School with foreign languages learning",
            "Professional High School \'Asen Zlatarev\'",
            "Primary School \'Lazar Stanev\' "});
            this.schoolComboBox.Location = new System.Drawing.Point(193, 301);
            this.schoolComboBox.Name = "schoolComboBox";
            this.schoolComboBox.Size = new System.Drawing.Size(121, 21);
            this.schoolComboBox.TabIndex = 25;
            // 
            // pinTextBox
            // 
            this.pinTextBox.Location = new System.Drawing.Point(193, 94);
            this.pinTextBox.Name = "pinTextBox";
            this.pinTextBox.Size = new System.Drawing.Size(121, 20);
            this.pinTextBox.TabIndex = 24;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(193, 49);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(121, 20);
            this.nameTextBox.TabIndex = 23;
            // 
            // genderGroupBox
            // 
            this.genderGroupBox.Controls.Add(this.femaleRadioButton);
            this.genderGroupBox.Controls.Add(this.maleRadioButton);
            this.genderGroupBox.Location = new System.Drawing.Point(15, 173);
            this.genderGroupBox.Name = "genderGroupBox";
            this.genderGroupBox.Size = new System.Drawing.Size(299, 71);
            this.genderGroupBox.TabIndex = 26;
            this.genderGroupBox.TabStop = false;
            this.genderGroupBox.Text = "Gender:";
            // 
            // femaleRadioButton
            // 
            this.femaleRadioButton.AutoSize = true;
            this.femaleRadioButton.Location = new System.Drawing.Point(149, 29);
            this.femaleRadioButton.Name = "femaleRadioButton";
            this.femaleRadioButton.Size = new System.Drawing.Size(56, 17);
            this.femaleRadioButton.TabIndex = 4;
            this.femaleRadioButton.TabStop = true;
            this.femaleRadioButton.Text = "female";
            this.femaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // maleRadioButton
            // 
            this.maleRadioButton.AutoSize = true;
            this.maleRadioButton.Location = new System.Drawing.Point(67, 29);
            this.maleRadioButton.Name = "maleRadioButton";
            this.maleRadioButton.Size = new System.Drawing.Size(47, 17);
            this.maleRadioButton.TabIndex = 3;
            this.maleRadioButton.TabStop = true;
            this.maleRadioButton.Text = "male";
            this.maleRadioButton.UseVisualStyleBackColor = true;
            // 
            // colorButton
            // 
            this.colorButton.Location = new System.Drawing.Point(443, 129);
            this.colorButton.Name = "colorButton";
            this.colorButton.Size = new System.Drawing.Size(91, 37);
            this.colorButton.TabIndex = 28;
            this.colorButton.Text = "Color";
            this.colorButton.UseVisualStyleBackColor = true;
            this.colorButton.Click += new System.EventHandler(this.colorButton_Click);
            // 
            // fontBution
            // 
            this.fontBution.Location = new System.Drawing.Point(540, 129);
            this.fontBution.Name = "fontBution";
            this.fontBution.Size = new System.Drawing.Size(91, 37);
            this.fontBution.TabIndex = 29;
            this.fontBution.Text = "Font";
            this.fontBution.UseVisualStyleBackColor = true;
            this.fontBution.Click += new System.EventHandler(this.fontButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(346, 214);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(91, 37);
            this.addButton.TabIndex = 30;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(346, 268);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(91, 37);
            this.clearButton.TabIndex = 31;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // foreignLanguagesGruopBox
            // 
            this.foreignLanguagesGruopBox.Controls.Add(this.russianCheckBox);
            this.foreignLanguagesGruopBox.Controls.Add(this.frenchCheckBox);
            this.foreignLanguagesGruopBox.Controls.Add(this.deutschCheckBox);
            this.foreignLanguagesGruopBox.Controls.Add(this.englishCheckBox);
            this.foreignLanguagesGruopBox.Location = new System.Drawing.Point(15, 346);
            this.foreignLanguagesGruopBox.Name = "foreignLanguagesGruopBox";
            this.foreignLanguagesGruopBox.Size = new System.Drawing.Size(299, 82);
            this.foreignLanguagesGruopBox.TabIndex = 27;
            this.foreignLanguagesGruopBox.TabStop = false;
            this.foreignLanguagesGruopBox.Text = "Foreign Languages:";
            // 
            // russianCheckBox
            // 
            this.russianCheckBox.AutoSize = true;
            this.russianCheckBox.Location = new System.Drawing.Point(214, 40);
            this.russianCheckBox.Name = "russianCheckBox";
            this.russianCheckBox.Size = new System.Drawing.Size(64, 17);
            this.russianCheckBox.TabIndex = 8;
            this.russianCheckBox.Text = "Russian";
            this.russianCheckBox.UseVisualStyleBackColor = true;
            // 
            // frenchCheckBox
            // 
            this.frenchCheckBox.AutoSize = true;
            this.frenchCheckBox.Location = new System.Drawing.Point(149, 40);
            this.frenchCheckBox.Name = "frenchCheckBox";
            this.frenchCheckBox.Size = new System.Drawing.Size(59, 17);
            this.frenchCheckBox.TabIndex = 7;
            this.frenchCheckBox.Text = "French";
            this.frenchCheckBox.UseVisualStyleBackColor = true;
            // 
            // deutschCheckBox
            // 
            this.deutschCheckBox.AutoSize = true;
            this.deutschCheckBox.Location = new System.Drawing.Point(77, 40);
            this.deutschCheckBox.Name = "deutschCheckBox";
            this.deutschCheckBox.Size = new System.Drawing.Size(66, 17);
            this.deutschCheckBox.TabIndex = 6;
            this.deutschCheckBox.Text = "Deutsch";
            this.deutschCheckBox.UseVisualStyleBackColor = true;
            // 
            // englishCheckBox
            // 
            this.englishCheckBox.AutoSize = true;
            this.englishCheckBox.Location = new System.Drawing.Point(11, 40);
            this.englishCheckBox.Name = "englishCheckBox";
            this.englishCheckBox.Size = new System.Drawing.Size(60, 17);
            this.englishCheckBox.TabIndex = 5;
            this.englishCheckBox.Text = "English";
            this.englishCheckBox.UseVisualStyleBackColor = true;
            // 
            // StudentsListView
            // 
            this.StudentsListView.FormattingEnabled = true;
            this.StudentsListView.Location = new System.Drawing.Point(443, 172);
            this.StudentsListView.Name = "StudentsListView";
            this.StudentsListView.Size = new System.Drawing.Size(382, 186);
            this.StudentsListView.TabIndex = 32;
            // 
            // schoolLabel
            // 
            this.schoolLabel.AutoSize = true;
            this.schoolLabel.Location = new System.Drawing.Point(12, 309);
            this.schoolLabel.Name = "schoolLabel";
            this.schoolLabel.Size = new System.Drawing.Size(43, 13);
            this.schoolLabel.TabIndex = 21;
            this.schoolLabel.Text = "School:";
            // 
            // pinLabel
            // 
            this.pinLabel.AutoSize = true;
            this.pinLabel.Location = new System.Drawing.Point(12, 101);
            this.pinLabel.Name = "pinLabel";
            this.pinLabel.Size = new System.Drawing.Size(154, 13);
            this.pinLabel.TabIndex = 22;
            this.pinLabel.Text = "Personal Identification Number:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(12, 57);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(38, 13);
            this.nameLabel.TabIndex = 20;
            this.nameLabel.Text = "Name:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 450);
            this.Controls.Add(this.dateOfBirthLabel);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.editorLabel);
            this.Controls.Add(this.schoolInformationLabel);
            this.Controls.Add(this.personalInformationLabel);
            this.Controls.Add(this.schoolComboBox);
            this.Controls.Add(this.pinTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.genderGroupBox);
            this.Controls.Add(this.colorButton);
            this.Controls.Add(this.fontBution);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.foreignLanguagesGruopBox);
            this.Controls.Add(this.StudentsListView);
            this.Controls.Add(this.schoolLabel);
            this.Controls.Add(this.pinLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.genderGroupBox.ResumeLayout(false);
            this.genderGroupBox.PerformLayout();
            this.foreignLanguagesGruopBox.ResumeLayout(false);
            this.foreignLanguagesGruopBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dateOfBirthLabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Label editorLabel;
        private System.Windows.Forms.Label schoolInformationLabel;
        private System.Windows.Forms.Label personalInformationLabel;
        private System.Windows.Forms.ComboBox schoolComboBox;
        private System.Windows.Forms.TextBox pinTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.GroupBox genderGroupBox;
        private System.Windows.Forms.RadioButton femaleRadioButton;
        private System.Windows.Forms.RadioButton maleRadioButton;
        private System.Windows.Forms.Button colorButton;
        private System.Windows.Forms.Button fontBution;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.GroupBox foreignLanguagesGruopBox;
        private System.Windows.Forms.CheckBox russianCheckBox;
        private System.Windows.Forms.CheckBox frenchCheckBox;
        private System.Windows.Forms.CheckBox deutschCheckBox;
        private System.Windows.Forms.CheckBox englishCheckBox;
        private System.Windows.Forms.ListBox StudentsListView;
        private System.Windows.Forms.Label schoolLabel;
        private System.Windows.Forms.Label pinLabel;
        private System.Windows.Forms.Label nameLabel;
    }
}


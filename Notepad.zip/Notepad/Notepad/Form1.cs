﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notepad
{
    public partial class Form1 : Form
    {
        public string[] RTBRedoUndo;
        public int StackCount = -1;
        public bool IsRedoUndo = false;
        public string[] RTBRedo;
        public int RedoStackCount = -1;

        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.Font = fontDialog.Font;
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            Graphics graph = richTextBox1.CreateGraphics();
            PointF location = new PointF(0, 0);
            RenderDropshadowText(graph, richTextBox1.Text, richTextBox1.Font, richTextBox1.ForeColor, Color.Gray, 20, location);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (StackCount > -1 && RTBRedoUndo[StackCount] != null)
            {
                IsRedoUndo = true;
                RedoStackCount += 1;
                RTBRedo[RedoStackCount] = RTBRedoUndo[StackCount];
                richTextBox1.Text = richTextBox1.Text.Substring(0, richTextBox1.Text.Length - 1);
                RTBRedoUndo[StackCount] = null;
                StackCount -= 1;

            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (RedoStackCount > -1 && RTBRedo[RedoStackCount] != null)
            {
                IsRedoUndo = true;
                StackCount += 1;
                RTBRedoUndo[StackCount] = RTBRedo[RedoStackCount];
                richTextBox1.Text = richTextBox1.Text + RTBRedo[RedoStackCount];
                RTBRedo[RedoStackCount] = null;
                RedoStackCount -= 1;
            }
        }

        private void btn_redo_MouseUp(object sender, MouseEventArgs e)
        {
            IsRedoUndo = false;
        }

        private void btn_undo_MouseUp(object sender, MouseEventArgs e)
        {
            IsRedoUndo = false;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            FontStyle style = richTextBox1.SelectionFont.Style;
            if (richTextBox1.SelectionFont.Bold)
            {
                style = style & ~FontStyle.Bold;
                richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Regular);
            }
            else
            {
                style = style | FontStyle.Bold;
                richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Bold);
            }
            richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, style);
            richTextBox1.Focus();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            FontStyle style = richTextBox1.SelectionFont.Style;
            if (richTextBox1.SelectionFont.Italic)
            {
                style = style & ~FontStyle.Italic;
                richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Regular);
            }
            else
            {
                style = style | FontStyle.Italic;
                richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Italic);
            }
            richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, style);
            richTextBox1.Focus();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            FontStyle style = richTextBox1.SelectionFont.Style;
            if (richTextBox1.SelectionFont.Underline)
            {
                style = style & ~FontStyle.Underline;
                richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Regular);
            }
            else
            {
                style = style | FontStyle.Underline;
                richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Underline);
            }
            richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, style);
            richTextBox1.Focus();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FontStyle style = richTextBox1.SelectionFont.Style;
            if (richTextBox1.SelectionFont.Strikeout)
            {
                style = style & ~FontStyle.Strikeout;
                richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Regular);
            }
            else
            {
                style = style | FontStyle.Strikeout;
                richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Strikeout);
            }
            richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, style);
            richTextBox1.Focus();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text != "" || richTextBox1.Text != null)
                richTextBox1.Cut();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (richTextBox1.TextLength > 0)
                richTextBox1.Copy();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                if (richTextBox1.TextLength > 0)
                {
                    richTextBox1.Paste();
                }
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.ForeColor = colorDialog.Color;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            ColorDialog color = new ColorDialog();
            if (color.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.BackColor = color.Color;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Left;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Center;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Right;
        }

        protected void RenderDropshadowText(
            Graphics graphics, string text, Font font, Color foreground, Color shadow,
            int shadowAlpha, PointF location)
        {
            const int DISTANCE = 2;
            for (int offset = 1; 0 <= offset; offset--)
            {
                Color color = ((offset < 1) ?
                    foreground : Color.FromArgb(shadowAlpha, shadow));
                using (var brush = new SolidBrush(color))
                {
                    var point = new PointF()
                    {
                        X = location.X + (offset * DISTANCE),
                        Y = location.Y + (offset * DISTANCE)
                    };
                    graphics.DrawString(text, font, brush, point);
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            if (open.ShowDialog() == DialogResult.OK)
            {
                string fileName = open.FileName;
                if (File.Exists(fileName))
                {
                    richTextBox1.Text = File.ReadAllText(fileName);
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveAs = new SaveFileDialog();

            if (saveAs.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveAs.FileName;
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                using (FileStream fs = File.Create(fileName))
                {
                    Byte[] text = new UTF8Encoding(true).GetBytes(richTextBox1.Text);
                    fs.Write(text, 0, text.Length);
                }
                label1.Visible = true;
                label1.Text = "Saved document -> " + saveAs.FileName;
            }
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (StackCount > -1 && RTBRedoUndo[StackCount] != null)
            {
                IsRedoUndo = true;
                RedoStackCount += 1;
                RTBRedo[RedoStackCount] = RTBRedoUndo[StackCount];
                richTextBox1.Text = richTextBox1.Text.Substring(0, richTextBox1.Text.Length - 1);
                RTBRedoUndo[StackCount] = null;
                StackCount -= 1;

            }
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (RedoStackCount > -1 && RTBRedo[RedoStackCount] != null)
            {
                IsRedoUndo = true;
                StackCount += 1;
                RTBRedoUndo[StackCount] = RTBRedo[RedoStackCount];
                richTextBox1.Text = richTextBox1.Text + RTBRedo[RedoStackCount];
                RTBRedo[RedoStackCount] = null;
                RedoStackCount -= 1;
            }
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text != "" || richTextBox1.Text != null)
                richTextBox1.Cut();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.TextLength > 0)
                richTextBox1.Copy();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
            {
                if (richTextBox1.TextLength > 0)
                {
                    richTextBox1.Paste();
                }
            }
        }

        private void statusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            if (richTextBox1.Text == null || richTextBox1.Text == "")
            {
                label1.Text = "Blank document";
            }
            else if (richTextBox1.Text != null && richTextBox1.Text != "")
            {
                label1.Text = "In progress";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RTBRedoUndo = new string[10000];
            RTBRedo = new string[10000];
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (IsRedoUndo == false)
            {
                StackCount += 1;
                RTBRedoUndo[StackCount] = richTextBox1.Text.Substring(richTextBox1.Text.Length - 1, 1);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form newForm = new Form();
            RichTextBox txt = new RichTextBox();
            txt.Text = "This is my simple notepad! -> Author: Petya Licheva, 12g class, 2021";
            txt.ReadOnly = true;
            newForm.Controls.Add(txt);
            newForm.Show();
        }
    }
}
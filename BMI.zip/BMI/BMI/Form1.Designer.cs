﻿
namespace BMI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.calcBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.bmi = new System.Windows.Forms.Label();
            this.hLbl = new System.Windows.Forms.Label();
            this.wLbl = new System.Windows.Forms.Label();
            this.hTxt = new System.Windows.Forms.TextBox();
            this.wTxt = new System.Windows.Forms.TextBox();
            this.gendersGroup = new System.Windows.Forms.GroupBox();
            this.maleLbl = new System.Windows.Forms.RadioButton();
            this.femaleLbl = new System.Windows.Forms.RadioButton();
            this.scale = new System.Windows.Forms.PictureBox();
            this.m1 = new System.Windows.Forms.PictureBox();
            this.m5 = new System.Windows.Forms.PictureBox();
            this.m4 = new System.Windows.Forms.PictureBox();
            this.w2 = new System.Windows.Forms.PictureBox();
            this.w1 = new System.Windows.Forms.PictureBox();
            this.w3 = new System.Windows.Forms.PictureBox();
            this.w4 = new System.Windows.Forms.PictureBox();
            this.w5 = new System.Windows.Forms.PictureBox();
            this.m3 = new System.Windows.Forms.PictureBox();
            this.m2 = new System.Windows.Forms.PictureBox();
            this.yourResLbl = new System.Windows.Forms.Label();
            this.resLbl = new System.Windows.Forms.Label();
            this.gendersGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.w2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.w1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.w3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.w4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.w5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m2)).BeginInit();
            this.SuspendLayout();
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(90, 281);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(75, 23);
            this.calcBtn.TabIndex = 0;
            this.calcBtn.Text = "Calculate";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(192, 281);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 23);
            this.clearBtn.TabIndex = 1;
            this.clearBtn.Text = "Clear";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // bmi
            // 
            this.bmi.AutoSize = true;
            this.bmi.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bmi.ForeColor = System.Drawing.Color.Maroon;
            this.bmi.Location = new System.Drawing.Point(12, 8);
            this.bmi.Name = "bmi";
            this.bmi.Size = new System.Drawing.Size(275, 32);
            this.bmi.TabIndex = 2;
            this.bmi.Text = "Body Mass Index";
            // 
            // hLbl
            // 
            this.hLbl.AutoSize = true;
            this.hLbl.Location = new System.Drawing.Point(20, 99);
            this.hLbl.Name = "hLbl";
            this.hLbl.Size = new System.Drawing.Size(64, 13);
            this.hLbl.TabIndex = 3;
            this.hLbl.Text = "Height (cm):";
            // 
            // wLbl
            // 
            this.wLbl.AutoSize = true;
            this.wLbl.Location = new System.Drawing.Point(20, 136);
            this.wLbl.Name = "wLbl";
            this.wLbl.Size = new System.Drawing.Size(65, 13);
            this.wLbl.TabIndex = 4;
            this.wLbl.Text = "Weight (kg):";
            // 
            // hTxt
            // 
            this.hTxt.Location = new System.Drawing.Point(90, 92);
            this.hTxt.Name = "hTxt";
            this.hTxt.Size = new System.Drawing.Size(177, 20);
            this.hTxt.TabIndex = 5;
            // 
            // wTxt
            // 
            this.wTxt.Location = new System.Drawing.Point(90, 129);
            this.wTxt.Name = "wTxt";
            this.wTxt.Size = new System.Drawing.Size(177, 20);
            this.wTxt.TabIndex = 6;
            // 
            // gendersGroup
            // 
            this.gendersGroup.Controls.Add(this.maleLbl);
            this.gendersGroup.Controls.Add(this.femaleLbl);
            this.gendersGroup.Location = new System.Drawing.Point(90, 164);
            this.gendersGroup.Name = "gendersGroup";
            this.gendersGroup.Size = new System.Drawing.Size(177, 95);
            this.gendersGroup.TabIndex = 7;
            this.gendersGroup.TabStop = false;
            this.gendersGroup.Text = "Genders:";
            // 
            // maleLbl
            // 
            this.maleLbl.AutoSize = true;
            this.maleLbl.Location = new System.Drawing.Point(7, 66);
            this.maleLbl.Name = "maleLbl";
            this.maleLbl.Size = new System.Drawing.Size(47, 17);
            this.maleLbl.TabIndex = 1;
            this.maleLbl.TabStop = true;
            this.maleLbl.Text = "male";
            this.maleLbl.UseVisualStyleBackColor = true;
            // 
            // femaleLbl
            // 
            this.femaleLbl.AutoSize = true;
            this.femaleLbl.Location = new System.Drawing.Point(7, 33);
            this.femaleLbl.Name = "femaleLbl";
            this.femaleLbl.Size = new System.Drawing.Size(56, 17);
            this.femaleLbl.TabIndex = 0;
            this.femaleLbl.TabStop = true;
            this.femaleLbl.Text = "female";
            this.femaleLbl.UseVisualStyleBackColor = true;
            // 
            // scale
            // 
            this.scale.Image = ((System.Drawing.Image)(resources.GetObject("scale.Image")));
            this.scale.Location = new System.Drawing.Point(301, 8);
            this.scale.Name = "scale";
            this.scale.Size = new System.Drawing.Size(574, 78);
            this.scale.TabIndex = 2;
            this.scale.TabStop = false;
            // 
            // m1
            // 
            this.m1.Image = ((System.Drawing.Image)(resources.GetObject("m1.Image")));
            this.m1.Location = new System.Drawing.Point(301, 92);
            this.m1.Name = "m1";
            this.m1.Size = new System.Drawing.Size(110, 212);
            this.m1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.m1.TabIndex = 3;
            this.m1.TabStop = false;
            // 
            // m5
            // 
            this.m5.Image = ((System.Drawing.Image)(resources.GetObject("m5.Image")));
            this.m5.Location = new System.Drawing.Point(764, 92);
            this.m5.Name = "m5";
            this.m5.Size = new System.Drawing.Size(110, 212);
            this.m5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.m5.TabIndex = 4;
            this.m5.TabStop = false;
            // 
            // m4
            // 
            this.m4.Image = ((System.Drawing.Image)(resources.GetObject("m4.Image")));
            this.m4.Location = new System.Drawing.Point(649, 92);
            this.m4.Name = "m4";
            this.m4.Size = new System.Drawing.Size(110, 212);
            this.m4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.m4.TabIndex = 5;
            this.m4.TabStop = false;
            // 
            // w2
            // 
            this.w2.Image = ((System.Drawing.Image)(resources.GetObject("w2.Image")));
            this.w2.Location = new System.Drawing.Point(417, 92);
            this.w2.Name = "w2";
            this.w2.Size = new System.Drawing.Size(110, 212);
            this.w2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.w2.TabIndex = 6;
            this.w2.TabStop = false;
            // 
            // w1
            // 
            this.w1.Image = ((System.Drawing.Image)(resources.GetObject("w1.Image")));
            this.w1.Location = new System.Drawing.Point(301, 92);
            this.w1.Name = "w1";
            this.w1.Size = new System.Drawing.Size(110, 212);
            this.w1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.w1.TabIndex = 7;
            this.w1.TabStop = false;
            // 
            // w3
            // 
            this.w3.Image = ((System.Drawing.Image)(resources.GetObject("w3.Image")));
            this.w3.Location = new System.Drawing.Point(533, 92);
            this.w3.Name = "w3";
            this.w3.Size = new System.Drawing.Size(110, 212);
            this.w3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.w3.TabIndex = 8;
            this.w3.TabStop = false;
            // 
            // w4
            // 
            this.w4.Image = ((System.Drawing.Image)(resources.GetObject("w4.Image")));
            this.w4.Location = new System.Drawing.Point(649, 92);
            this.w4.Name = "w4";
            this.w4.Size = new System.Drawing.Size(110, 212);
            this.w4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.w4.TabIndex = 9;
            this.w4.TabStop = false;
            // 
            // w5
            // 
            this.w5.Image = ((System.Drawing.Image)(resources.GetObject("w5.Image")));
            this.w5.Location = new System.Drawing.Point(765, 92);
            this.w5.Name = "w5";
            this.w5.Size = new System.Drawing.Size(109, 212);
            this.w5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.w5.TabIndex = 10;
            this.w5.TabStop = false;
            // 
            // m3
            // 
            this.m3.Image = ((System.Drawing.Image)(resources.GetObject("m3.Image")));
            this.m3.Location = new System.Drawing.Point(533, 92);
            this.m3.Name = "m3";
            this.m3.Size = new System.Drawing.Size(110, 212);
            this.m3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.m3.TabIndex = 11;
            this.m3.TabStop = false;
            // 
            // m2
            // 
            this.m2.Image = ((System.Drawing.Image)(resources.GetObject("m2.Image")));
            this.m2.Location = new System.Drawing.Point(417, 92);
            this.m2.Name = "m2";
            this.m2.Size = new System.Drawing.Size(110, 212);
            this.m2.TabIndex = 13;
            this.m2.TabStop = false;
            // 
            // yourResLbl
            // 
            this.yourResLbl.AutoSize = true;
            this.yourResLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yourResLbl.ForeColor = System.Drawing.Color.Maroon;
            this.yourResLbl.Location = new System.Drawing.Point(295, 323);
            this.yourResLbl.Name = "yourResLbl";
            this.yourResLbl.Size = new System.Drawing.Size(173, 31);
            this.yourResLbl.TabIndex = 14;
            this.yourResLbl.Text = "Your BMI is:";
            // 
            // resLbl
            // 
            this.resLbl.AutoSize = true;
            this.resLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resLbl.Location = new System.Drawing.Point(528, 329);
            this.resLbl.Name = "resLbl";
            this.resLbl.Size = new System.Drawing.Size(0, 25);
            this.resLbl.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 362);
            this.Controls.Add(this.resLbl);
            this.Controls.Add(this.yourResLbl);
            this.Controls.Add(this.scale);
            this.Controls.Add(this.m1);
            this.Controls.Add(this.w1);
            this.Controls.Add(this.m5);
            this.Controls.Add(this.m4);
            this.Controls.Add(this.w2);
            this.Controls.Add(this.w3);
            this.Controls.Add(this.w4);
            this.Controls.Add(this.w5);
            this.Controls.Add(this.m3);
            this.Controls.Add(this.m2);
            this.Controls.Add(this.gendersGroup);
            this.Controls.Add(this.wTxt);
            this.Controls.Add(this.hTxt);
            this.Controls.Add(this.wLbl);
            this.Controls.Add(this.hLbl);
            this.Controls.Add(this.bmi);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.calcBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.gendersGroup.ResumeLayout(false);
            this.gendersGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.w2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.w1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.w3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.w4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.w5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calcBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Label bmi;
        private System.Windows.Forms.Label hLbl;
        private System.Windows.Forms.Label wLbl;
        private System.Windows.Forms.TextBox hTxt;
        private System.Windows.Forms.TextBox wTxt;
        private System.Windows.Forms.GroupBox gendersGroup;
        private System.Windows.Forms.RadioButton maleLbl;
        private System.Windows.Forms.RadioButton femaleLbl;
        private System.Windows.Forms.PictureBox scale;
        private System.Windows.Forms.PictureBox m1;
        private System.Windows.Forms.PictureBox m5;
        private System.Windows.Forms.PictureBox m4;
        private System.Windows.Forms.PictureBox w2;
        private System.Windows.Forms.PictureBox w1;
        private System.Windows.Forms.PictureBox w3;
        private System.Windows.Forms.PictureBox w4;
        private System.Windows.Forms.PictureBox w5;
        private System.Windows.Forms.PictureBox m3;
        private System.Windows.Forms.PictureBox m2;
        private System.Windows.Forms.Label yourResLbl;
        private System.Windows.Forms.Label resLbl;
    }
}


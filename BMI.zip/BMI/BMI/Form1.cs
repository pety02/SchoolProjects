﻿using System;
using System.Windows.Forms;

namespace BMI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            clearBMI();
        }

        private void calcBtn_Click(object sender, EventArgs e)
        {
            if (hTxt.Text != null && wTxt.Text != null && (femaleLbl.Checked || maleLbl.Checked))
            {
                clearBtn.Enabled = true;
            }

            calculateBMI();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            clearBMI();
        }

        private void clearBMI()
        {
            hTxt.Clear();
            wTxt.Clear();
            clearBtn.Enabled = false;

            m1.Hide();
            m2.Hide();
            m3.Hide();
            m4.Hide();
            m5.Hide();

            w1.Hide();
            w2.Hide();
            w3.Hide();
            w4.Hide();
            w5.Hide();
        }

        private void calculateBMI()
        {
            try
            {
                if (hTxt.Text != null || wTxt.Text != null || hTxt.Text != "" || wTxt.Text != "" || System.Text.RegularExpressions.Regex.IsMatch(wTxt.Text, "[^0-9]") || System.Text.RegularExpressions.Regex.IsMatch(hTxt.Text, "[^0-9]"))
                {
                    double weight = Double.Parse(wTxt.Text);
                    double height = Double.Parse(hTxt.Text) / 100;
                    double bmi = Math.Round((weight / Math.Pow(height, 2)), 2);

                    resLbl.Text = bmi.ToString();
                    if (femaleLbl.Checked)
                    {
                        if (bmi >= 0 && bmi < 18.5)
                        {
                            w1.Show();
                            MessageBox.Show("If you want to be healthy, you sould gain weight!", "You are underweight!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (bmi >= 18.5 && bmi <= 25)
                        {
                            w2.Show();
                            MessageBox.Show("If you want to be healthy, you sould save your weight, without gaining or loosing kilograms!", "Your weight is normal!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (bmi > 25 && bmi <= 30)
                        {
                            w3.Show();
                            MessageBox.Show("If you want to be healthy, you sould start a diet!", "You are overweight!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (bmi > 30 && bmi <= 35)
                        {
                            w4.Show();
                            MessageBox.Show("If you want to be healthy, you sould start a diet and start workouting!", "You are obese!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (bmi > 35)
                        {
                            w5.Show();
                            MessageBox.Show("If you want to be healthy, you sould visit a dietolog, start diet and start workouting, imediately!", "You are extremly obese!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            throw new ArgumentException("Your BMI is an invalid number!");
                        }
                    }

                    if (maleLbl.Checked)
                    {
                        if (bmi >= 0 && bmi < 18.5)
                        {
                            m1.Show();
                            MessageBox.Show("If you want to be healthy, you sould gain weight!", "You are underweight!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (bmi >= 18.5 && bmi <= 25)
                        {
                            m2.Show();
                            MessageBox.Show("If you want to be healthy, you sould save your weight, without gaining or loosing kilograms!", "Your weight is normal!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (bmi > 25 && bmi <= 30)
                        {
                            m3.Show();
                            MessageBox.Show("If you want to be healthy, you sould start a diet!", "You are overweight!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (bmi > 30 && bmi <= 35)
                        {
                            m4.Show();
                            MessageBox.Show("If you want to be healthy, you sould start a diet and start workouting!", "You are obese!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (bmi > 35)
                        {
                            m5.Show();
                            MessageBox.Show("If you want to be healthy, you sould visit a dietolog, start diet and start workouting, imediately!", "You are extremly obese!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            throw new ArgumentException("Your BMI is an invalid number!");
                        }
                    }

                    if (!femaleLbl.Checked && !maleLbl.Checked)
                    {
                        throw new ArgumentException("You did not choose your gender!");
                    }

                }
                else
                {
                    throw new ArgumentException("You did not type a valid information about your height, weight or both of them!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Invalid Data!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Games.Models;

namespace Games.Controllers
{
    public class HomeController : Controller
    {
        static int rowsCount = 5;
        static int colsCount = 10;
        static string[,] fruits = GenerateRandomFruits();
        static int score = 0;
        static bool gameOver = false;
        static int fruitCnt = -1;

        public IActionResult Index()
        {
            ViewBag.rowsCount = rowsCount;
            ViewBag.colsCount = colsCount;
            ViewBag.fruits = fruits;
            ViewBag.score = score;
            ViewBag.gameOver = gameOver;
            ViewBag.fruitCnt = fruitCnt;
            return View();
        }

        public IActionResult FireTop(int position) {

            return Fire(position, 0, 1);
        }

        public IActionResult FireBottom(int position) {

            return Fire(position, rowsCount-1, -1);
        }

        public IActionResult FireLeft(int position) {

            return Fire(position, 0, 1);
        }

        public IActionResult FireRight(int position) {

            return Fire(position, colsCount-1, -1);
        }

        public IActionResult Reset() {

            fruits = GenerateRandomFruits();
            score = 0;
            gameOver = false;
            return RedirectToAction("Index");
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Fire(int position, int startRow, int step)
        {
            var col = position * (colsCount - 1) / 100;
            var row = startRow;
            while (row >= 0 && row < rowsCount)
            {
                var fruit = fruits[row, col];
                if (fruit.Equals("apple") || fruit.Equals("orange") || fruit.Equals("banana") || fruit.Equals("kiwi"))
                {
                    switch(fruit){

                        case "apple": score += 2; break;
                        case "orange": score += 3; break;
                        case "banana": score += 4; break;
                        case "kiwi": score += 5; break;
                        default: score++; break;
                    }
                    fruits[row, col] = "empty";
                    fruitCnt--;
                    break;
                }
                else if (fruit.Equals("dynamite"))
                {
                    gameOver = true;
                    break;
                }
                row += step;
            }
            return RedirectToAction("Index");
        }

        [NonAction]
        public static string[,] GenerateRandomFruits() {

            var rand = new Random();
            string[,] frs = new string[rowsCount, colsCount];
            for (int r = 0; r < rowsCount; r++)
            {
                for (int c = 0; c < colsCount; c++)
                {
                    var row = rand.Next(10);
                    if (row < 2) { frs[r, c] = "apple"; fruitCnt++; }
                    else if (row < 4) { frs[r, c] = "banana"; fruitCnt++; }
                    else if (row < 6) { frs[r, c] = "orange"; fruitCnt++; }
                    else if (row < 8) { frs[r, c] = "kiwi"; fruitCnt++; }
                    else frs[r, c] = "dynamite";
                }
            }
            return frs;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MemoryGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[] a = new int[102];

        Button[] b = new Button[102];

        int br, br1 = -1, br2 = -1, n, m, fl, flag = 0, sec;

        DateTime t;

        private void shuffle()

        {

            Random r = new Random();

            for (int i = 1; i <= n / 2; i++)

            {

                a[i] = i;

                a[i + n / 2] = i;

            }

            for (int i = 1; i <= n; i++)

            {

                int x = r.Next() % n + 1;

                int temp = a[i];

                a[i] = a[x];

                a[x] = temp;

            }

        }

        private void draw(int n, int m)

        {

            shuffle();

            for (int i = 1; i <= n; i++)

            {

                b[i] = new Button();

                b[i].Parent = this;

                b[i].Top = 100 + ((i - 1) / m) * 105;

                b[i].Left = 100 + ((i - 1) % m) * 105;

                b[i].Height = 100;

                b[i].Width = 100;

                b[i].Click += new EventHandler(Form1_Click);

                b[i].Tag = i;

                b[i].ImageList = imageList1;

                b[i].BackColor = System.Drawing.Color.FromArgb(55, 128, 128);

                b[i].ForeColor = System.Drawing.Color.FromArgb(255, 255, 30);

                this.Controls.Add(b[i]);

            }

            br = 0;

            fl = 0;

        }

        private void Form1_Click(object sender, EventArgs e)

        {

            if (!(sender is Button)) return;

            Button curbut = (Button)sender;

            int t = (int)curbut.Tag;

            if ((t == br1 && flag == 1) || (t == br2 && flag == 2)) return;

            br++;

            if (br % 2 == 1)

            {

                br1 = t;

                b[br1].ImageIndex = a[br1] - 1;

                this.Refresh();

                flag = 1;

            }

            else

            {

                br2 = t;

                b[br2].ImageIndex = a[br2] - 1;

                flag = 2;

                this.Refresh();

                Thread.Sleep(1000);

                if (a[br1] == a[br2])

                {

                    fl++;

                    b[br1].Enabled = false;

                    b[br2].Enabled = false;

                }

                else

                {

                    b[br1].ImageIndex = -1;

                    b[br2].ImageIndex = -1;

                }

            }

            if (fl == n / 2)

            {

                timer1.Stop();

                MessageBox.Show("БРАВО!");

            }

        }

        private void clear()

        {

            for (int i = 1; i <= n; i++)

                this.Controls.Remove(b[i]);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)

        {

            clear();

            if (comboBox1.SelectedIndex == 0)

            { n = 12; m = 3; sec = 40; }

            if (comboBox1.SelectedIndex == 1)

            { n = 16; m = 4; sec = 60; }

            if (comboBox1.SelectedIndex == 2)

            { n = 20; m = 5; sec = 80; }

            if (comboBox1.SelectedIndex == 3)

            { n = 30; m = 6; sec = 100; }

            if (comboBox1.SelectedIndex == 4)

            { n = 36; m = 6; sec = 120; }

            draw(n, m);

            t = DateTime.Now;

            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)

        {

            DateTime t1 = DateTime.Now;

            DateTime t2 = DateTime.Parse("00:00:00") + new TimeSpan(0, 0, sec);

            textBox2.Text = (t2 - (t1 - t)).ToString("mm:ss");

            if ((t2 - (t1 - t)).ToLongTimeString() == "00:00:00")

            {

                timer1.Stop();

                for (int i = 1; i <= n; i++)

                    b[i].Enabled = false;

                MessageBox.Show("Изтече времето!");

            }

        }
    }
}
